﻿using AutoMapper.Execution;
using FitZone.Application.Services.Implementations;
using FitZone.Application.Services.Interfaces;
using FitZone.Domain.Interfaces;
using FitZone.Domain.Models.DTOs.MembersDTOs;
using FitZone.Infrastructure.Data;
using FitZone.Infrastructure.Repositories;
using Microsoft.Extensions.DependencyInjection;

namespace FitZone.UI
{
    internal class Program
    {
        static void Main(string[] args)
        {

            //DI Container

            var services = new ServiceCollection();

            services.AddLogging();

            //services.AddDbContext<FitZoneDbContext>();
            services.AddScoped<IMemberRepository, MemberRepository>();
            services.AddScoped<IMemberService, MemberService>();



            services.AddAutoMapper(cfg =>
            {
                cfg.AddMaps(typeof(MemberService).Assembly);
                cfg.AddMaps(typeof(Program).Assembly);
            });

            var serviceProvider = services.BuildServiceProvider();

            var memberService = serviceProvider.GetRequiredService<IMemberService>();
            
            var newMember = new CreateMemberDTO
            {
                FirstName = "John",
                LastName = "Doe",
                MembershipTypeId = 1
            };


            memberService.AddMember(newMember);

            var members = memberService.GetAllMembers();
            foreach (var item in members)
            {
                Console.WriteLine(item);
                
            }


        }
    }
}
